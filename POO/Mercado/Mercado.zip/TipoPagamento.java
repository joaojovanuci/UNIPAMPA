package merc;

public enum TipoPagamento {
	DINHEIRO,
	CHEQUE,
	CARTAO
}
