package merc;

public class Item {

	public int quantidade;
	public Item(int quantidade) {
		this.quantidade = quantidade;
	}

}
