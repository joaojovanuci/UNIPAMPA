package asp1;

public enum TipoTransacao {
	DEPOSITO, RETIRADA, TRANSFERENCIA
}
