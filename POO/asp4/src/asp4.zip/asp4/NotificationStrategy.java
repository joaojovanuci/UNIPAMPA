package asp4;

public interface NotificationStrategy {
	void processNotification(String message);
}
